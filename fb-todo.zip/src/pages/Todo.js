import React, { useEffect } from "react";
import { useState } from "react";
import List from "../components/List";
import Form from "../components/Form";
import { useNavigate } from "react-router-dom";
import { axiosInstance, deleteAllTodo } from "../axios/axios";
import Loading from "../components/Loading";
import { useAuthContext } from "../hooks/useFirebase";

const Todo = ({ fbName, fbEmail, fbUid }) => {
  // 사용자별 등록을 위해 user를 받아온다

  const { user } = useAuthContext();

  const navigator = useNavigate();

  console.log(fbName, fbEmail);
  // JsonServer 데이터 state 변수
  const initTodoData = [];
  const [todoData, setTodoData] = useState(initTodoData);

  const handleRemoveClick = () => {
    setTodoData([]);
    deleteAllTodo();
  };
  const getTodo = async () => {
    try {
      const res = await axiosInstance.get("/todos");
      const result = res.data;
      // 문제가 무엇인가? true false 가 문자열로 들어옴
      const todosArr = result.map(item => {
        if (item.completed === "true") {
          item.completed = true;
        } else {
          item.completed = false;
        }
        return item;
      });
      setTodoData(todosArr);
      //
      // item.completed = JSON.parse(item.completed);
    } catch (error) {
      console.log(error);
    }
  };
  // uid가 없는 경우 로그인으로 바로 보내기
  useEffect(() => {
    getTodo(setTodoData);
  }, []);
  return (
    <div className="flex justify-center items-start mt-5 w-full">
      {/* {isLoading && <Loading />} */}
      <div className="w-4/5 p-6 bg-white rounded-[6px] shadow">
        <div className="flex justify-between mb-3">
          <h1 className=" text-center w-3/4 text-2xl text-pink-600 font-semibold">
            Firebase Todo-List
          </h1>
          <button
            className="p-2 text-blue-400 border-2 border-blue-400 rounded hover:text-white hover:bg-blue-400 text-[12px]"
            onClick={handleRemoveClick}
          >
            Delete All
          </button>
        </div>
        {/* 할일 목록 */}
        <List todoData={todoData} setTodoData={setTodoData} />
        {/* 할일 추가 */}
        <Form
          todoData={todoData}
          setTodoData={setTodoData}
          fbName={fbName}
          fbEmail={fbEmail}
          uid={user.uid}
        />
      </div>
    </div>
  );
};

export default Todo;
