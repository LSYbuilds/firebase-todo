import React from "react";

const About = () => {
  return (
    <div className="p-6 mt-5 shadow rounded bg-white">
      <h1 className="w-full text-center text-lg text-black">ABOUT</h1>
    </div>
  );
};

export default About;
