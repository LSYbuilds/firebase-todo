import React from "react";
import HalfList from "./HalfList";

const Half = () => {
  return (
    <div>
      <HalfList />
    </div>
  );
};

export default Half;
