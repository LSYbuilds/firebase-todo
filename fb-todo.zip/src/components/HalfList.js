import React from "react";

const HalfList = () => {
  return <div>HalfList</div>;
};

export default HalfList;
