import React from "react";


const Listitem = () => {
  return (
    <div>
      {" "}
      <div style={getStyle(item.completed)} key={item.id}>
        {/* defaultChecked : 체크박스에 기본체크 상태 설정 */}
        <input
          type="checkbox"
          defaultChecked={item.completed}
          onChange={() => handleCompleteChange(item.id)}
        />
        <span className="item-title">{item.title}</span>
        <button style={btnStyle} onClick={() => handleClick(item.id)}>
          X
        </button>
      </div>
    </div>
  );
};

export default Listitem;
